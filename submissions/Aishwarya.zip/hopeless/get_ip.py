import requests, sys

if __name__ == "__main__":
    port = sys.argv[1]
    data =  requests.get(f"https://threads.iiit.ac.in:{port}/game/get_ip").json()
    print(data)
